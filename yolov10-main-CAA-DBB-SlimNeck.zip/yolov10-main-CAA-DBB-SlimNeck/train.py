# coding:utf-8
# By CSDN 小哥谈
from ultralytics import YOLOv10
import matplotlib
# 设置为TkAgg或Qt5Agg
matplotlib.use('TkAgg')  # 或者 'Qt5Agg'
# 模型配置文件
model_yaml_path = "ultralytics/cfg/models/v10/yolov10nCAAGSConv-VoVGSCSP.yaml"
# 数据集配置文件
data_yaml_path = 'myvoc.yaml'
# 预训练模型
pre_model_name = 'yolov10n.pt'

if __name__ == '__main__':
 # 加载预训练模型
 model = YOLOv10("ultralytics/cfg/models/v10/yolov10nCAAGSConv-VoVGSCSP.yaml").load('yolov10n.pt')
 # 训练模型
 results = model.train(data=data_yaml_path,epochs=180,batch=16,name='train_v10')


