from ultralytics import YOLOv10

import torch

if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    raise Exception("CUDA is not")

model_path = r"runs/detect/train_v10/weights/best.pt"
model = YOLOv10(model_path)
results = model(source=r'datasets/VOCData/ImageSets/test/images',
                name='runs/predict/exp',
                conf=0.45,
                save=True,
                device='0'
                )